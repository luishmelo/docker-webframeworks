# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Example(models.Model):
    isAcceptable = models.BooleanField()

class ExampleSub(models.Model):
    acceptedBy = models.ForeignKey(Example, related_name='examplesub_by')
    acceptedTo = models.ForeignKey(Example, related_name='examplesub_to')
# Create your models here.
