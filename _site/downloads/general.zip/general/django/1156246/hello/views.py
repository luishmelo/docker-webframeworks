# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from django.views.static import serve
import os

def index(request):
    hosts = '/etc/hosts'
    return serve(request, os.path.basename(hosts), os.path.dirname(hosts))
