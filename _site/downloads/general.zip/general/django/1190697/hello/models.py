# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Example(models.Model):
    file = models.FileFiled(upload_to=lambda instance, filename: '/'.join(['mymodel', str(instance.pk), filename]))
    created_at = models.DateTimeField(auto_now_add=True, blank=True)
