# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from django.core import serializers
from models import Example

def index(request):
    example = Example.objects.create()
    return HttpResponse(serializers.serialize('json', [example]))
