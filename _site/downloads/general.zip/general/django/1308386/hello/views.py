# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from .models import *
from django.core.files import File  # you need this somewhere
import urllib

def index(request):
    image = 'https://www.google.com.br/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png'
    example = Example()
    result = urllib.urlretrieve(image)
    example.image.save('/app/images/', File(open(result[0])))
    example.save()
    return HttpResponse("Hello, world.")
