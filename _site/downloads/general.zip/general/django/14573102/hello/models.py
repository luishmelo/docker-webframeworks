# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Master(models.Model):
    
    pass

class Item(models.Model):
    master = models.ForeignKey(Master, related_name='items')
