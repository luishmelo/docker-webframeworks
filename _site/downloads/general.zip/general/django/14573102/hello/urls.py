from django.conf.urls import url

from . import views

from rest_framework import routers

urlpatterns = [
#    url(r'^$', include('rest_framework.urls'), namespace='rest_framework'),
]
