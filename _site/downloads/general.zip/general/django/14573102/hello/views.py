# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from . import models
from django.db.models import Q
from rest_framework import routers, serializers, viewsets

class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Item
        fields = ('pk', 'master_id')

class MasterSerializer(serializers.ModelSerializer):
    items = ItemSerializer(source='items_set')
    class Meta:
        model = models.Master

class ViewSetR(viewsets.ModelViewSet):
    queryset = models.Master.objects.get(pk=1)
    serializer_class = MasterSerializer

router = routers.DefaultRouter()
router.register(r'/', ViewSetR)
