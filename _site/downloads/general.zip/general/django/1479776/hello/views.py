# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render

def test():
    return (1, 2, 3, 4, 5)

def index(request):
    a, b, c = test()
    return HttpResponse("Hello, world.")
