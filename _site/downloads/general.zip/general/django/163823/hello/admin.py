# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import Post

class PostAdmin(admin.ModelAdmin):
    list_display = ['get_author']

    def get_author(self, obj):
        return obj.author

admin.site.register(Post,PostAdmin)
