from django import template

register = template.Library()

@register.inclusion_tag('model.html', takes_context=True)
def example(context):
    request = context['request']
    return {'ip': request.META.get('REMOTE_ADDR')}
