# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Example(models.Model):
    field_one = models.CharField(max_length=10)
    field_two = models.CharField(max_length=10)

    class Meta:
        unique_together = ('field_one', 'field_two')
# Create your models here.
