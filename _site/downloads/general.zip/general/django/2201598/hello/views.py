# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from models import Example
from django.core import serializers

def index(request):
    ex = Example.objects.create(field_one='Hello', field_two='World')
    return HttpResponse(serializers.serialize('json', [ex]))
