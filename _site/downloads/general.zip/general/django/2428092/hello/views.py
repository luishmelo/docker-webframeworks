# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import json
from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    data = {}
    data['hello'] = 'World'
    return HttpResponse(json.dumps(data), content_type='application/json')
