# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from .models import *

def index(request):
    p = Post()
    p.author_id = 1
    p.save()
    posts = Post.objects.filter(author_id=1).all()
    return HttpResponse(posts)
