# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from . import models
from django.db.models import Count
from django.core import serializers

def index(request):
    kwargs = {
            '{0}__{1}'.format('name', 'startswith'): 'L',
            '{0}__{1}'.format('surname', 'startswith'): 'S',
    }
    surnames = models.User.objects.filter(**kwargs).all()
    return HttpResponse(serializers.serialize('json', surnames))
