# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from django.core.validators import validate_email

def index(request):
    try:
        validate_email('test@email.com')
        return HttpResponse("Valid email")
    except:
        return HttpResponse('Invalid email')
