# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from .forms import *
from .models import *

def index(request):
    Post.objects.create()
    form = PostForm()
    return render(request, 'test.html', {'form':form})
