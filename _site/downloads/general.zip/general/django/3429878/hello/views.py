# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from .models import User
from django.db.models import Q
from django.core import serializers

def index(request):
    new_user = User()
    new_user.name = 'Test'
    new_user.save()
    return HttpResponse(serializers.serialize('json', [new_user]))
