# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from . import models
import datetime
from django.db.models import Q
from django.core import serializers

def index(request):
    dates = models.Example.objects.filter(date__range=(datetime.date(2010,01,03),datetime.date(2010,01,9))).all()
    return HttpResponse(serializers.serialize('json', dates))
