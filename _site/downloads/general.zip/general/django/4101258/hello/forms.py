from django import forms
from .models import Post

class PostForm(forms.Form):
    q = forms.CharField(label='search', widget=forms.TextInput(attrs={'placeholder': 'Search'}))
