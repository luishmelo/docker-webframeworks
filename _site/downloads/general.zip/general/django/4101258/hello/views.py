# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from .forms import *

def index(request):
    form = PostForm()
    return render(request, 'test.html', {'form':form})
