# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import Post
from django.forms import TextInput, Textarea
from django.db import models

admin.site.site_header = 'Cool Admin'
admin.site.register(Post)
