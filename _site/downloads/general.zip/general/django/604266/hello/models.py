# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from datetime import datetime
from django.db import models

class Example(models.Model):
    created_at = models.DateTimeField(default=datetime.now)
