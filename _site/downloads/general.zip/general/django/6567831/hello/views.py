# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from . import models
from django.db.models import Q
from django.core import serializers

def index(request):
    notYoda = models.User.objects.filter(Q(name='Vader') | Q(name='Luke')).all()
    return HttpResponse(serializers.serialize('json', notYoda))
