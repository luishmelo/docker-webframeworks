# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponse
from django.shortcuts import render
from .models import *

def index(request):
    e1 = Example.objects.create()
    e2 = Example.objects.create()
    s = Sample.objects.create();
    s.examples.add(e1, e2)
    s.save()
    return HttpResponse("See hello/views.py")
