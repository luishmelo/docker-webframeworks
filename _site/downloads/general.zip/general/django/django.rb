done = Dir.glob '*'

probs = IO.read 'probs.txt'
probs = probs.lines

probs.each do |q|
	puts q if done.include? q.strip
end
